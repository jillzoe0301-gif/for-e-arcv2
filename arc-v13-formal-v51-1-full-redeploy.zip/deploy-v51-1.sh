#!/usr/bin/env bash
set -euo pipefail

SOURCE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TARGET_DIR="${1:-$(pwd)}"

if [ ! -d "$TARGET_DIR/.git" ]; then
  echo "錯誤：$TARGET_DIR 不是 Git 專案根目錄。"
  echo "請先 cd 到 /workspaces/for-e-arcv2，再重新執行。"
  exit 1
fi

cd "$TARGET_DIR"

echo "[1/7] 目前專案：$(pwd)"
echo "[2/7] 目前分支：$(git branch --show-current)"

if [ "$(git branch --show-current)" != "main" ]; then
  echo "錯誤：目前不是 main 分支，請先切換到 main。"
  exit 1
fi

mkdir -p src public scripts supabase
cp -a "$SOURCE_DIR/src/." ./src/
cp -a "$SOURCE_DIR/public/." ./public/
cp -a "$SOURCE_DIR/scripts/." ./scripts/
cp -a "$SOURCE_DIR/supabase/." ./supabase/
cp -f "$SOURCE_DIR/index.html" ./index.html
cp -f "$SOURCE_DIR/package.json" ./package.json
cp -f "$SOURCE_DIR/package-lock.json" ./package-lock.json
cp -f "$SOURCE_DIR/tsconfig.json" ./tsconfig.json
cp -f "$SOURCE_DIR/vite.config.ts" ./vite.config.ts
cp -f "$SOURCE_DIR/.npmrc" ./.npmrc
cp -f "$SOURCE_DIR/.gitignore" ./.gitignore
cp -f "$SOURCE_DIR/.env.example" ./.env.example
cp -f "$SOURCE_DIR/README_V51.md" ./README_V51.md
cp -f "$SOURCE_DIR/README_DEPLOY_V51_1.md" ./README_DEPLOY_V51_1.md

echo "[3/7] 已覆蓋 V51.1 程式檔案"

echo "[4/7] 版本檢查："
cat src/utils/version.ts

echo "[5/7] 安裝相依套件並編譯"
npm install
npm run build

echo "[6/7] Git 變更："
git status --short

git add -A
if git diff --cached --quiet; then
  echo "沒有檔案差異，建立空提交以強制 Vercel 重新部署。"
  git commit --allow-empty -m "Force redeploy ARC V51.1"
else
  git commit -m "Deploy ARC V51.1 corrected update"
fi

echo "[7/7] 推送 main"
git push origin main

echo "完成。請到 Vercel Deployments 確認最新提交已部署。"
echo "部署後畫面版本應顯示：ARC V13.51"
