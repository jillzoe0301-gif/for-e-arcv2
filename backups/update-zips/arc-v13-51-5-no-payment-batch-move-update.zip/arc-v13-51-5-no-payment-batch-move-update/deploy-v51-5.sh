#!/usr/bin/env bash
set -euo pipefail

PROJECT_DIR="${1:-/workspaces/for-e-arcv2}"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

if [ ! -f "$PROJECT_DIR/package.json" ]; then
  echo "找不到 ARC 專案：$PROJECT_DIR"
  exit 1
fi

cd "$PROJECT_DIR"

echo "[1/6] 覆蓋 ARC V13.51.5 更新檔"
cp -f "$SCRIPT_DIR/src/pages/PaymentPage.tsx" "src/pages/PaymentPage.tsx"
cp -f "$SCRIPT_DIR/src/utils/version.ts" "src/utils/version.ts"
cp -f "$SCRIPT_DIR/README_V51_5.md" "README_V51_5.md"

echo "[2/6] 確認版本"
cat src/utils/version.ts

echo "[3/6] 安裝相依套件"
npm install

echo "[4/6] 正式編譯"
npm run build

echo "[5/6] 提交 Git"
git add src/pages/PaymentPage.tsx src/utils/version.ts README_V51_5.md
if git diff --cached --quiet; then
  git commit --allow-empty -m "Trigger ARC V13.51.5 deployment"
else
  git commit -m "ARC V13.51.5 no-payment batch move to fax pickup"
fi

echo "[6/6] 推送 main 並觸發 Vercel"
git push origin HEAD:main

echo "部署推送完成。系統版本應顯示：ARC V13.51.5"
