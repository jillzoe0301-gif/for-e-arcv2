#!/usr/bin/env bash
set -euo pipefail
PROJECT_DIR="${1:-/workspaces/for-e-arcv2}"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$PROJECT_DIR"
cp -f "$SCRIPT_DIR/src/utils/print.ts" "$PROJECT_DIR/src/utils/print.ts"
cp -f "$SCRIPT_DIR/src/utils/version.ts" "$PROJECT_DIR/src/utils/version.ts"
cp -f "$SCRIPT_DIR/README_V51_3.md" "$PROJECT_DIR/README_V51_3.md"
echo "目前版本："
cat src/utils/version.ts
npm install
npm run build
git add src/utils/print.ts src/utils/version.ts README_V51_3.md
if git diff --cached --quiet; then
  git commit --allow-empty -m "Trigger ARC V51.3 deployment"
else
  git commit -m "ARC V51.3 set fax and signature print margins to 0.5cm"
fi
git push origin main
echo "ARC V13.51.3 已推送，請至 Vercel 確認部署。"
