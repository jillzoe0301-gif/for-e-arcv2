#!/usr/bin/env bash
set -euo pipefail

TARGET="${1:-/workspaces/for-e-arcv2}"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

if [[ ! -d "$TARGET/src" || ! -f "$TARGET/package.json" ]]; then
  echo "找不到 ARC 專案：$TARGET"
  exit 1
fi

cd "$TARGET"
cp -f "$SCRIPT_DIR/src/pages/PaymentPage.tsx" src/pages/PaymentPage.tsx
cp -f "$SCRIPT_DIR/src/pages/FinanceConfirmPage.tsx" src/pages/FinanceConfirmPage.tsx
cp -f "$SCRIPT_DIR/src/utils/sort.ts" src/utils/sort.ts
cp -f "$SCRIPT_DIR/src/utils/version.ts" src/utils/version.ts
cp -f "$SCRIPT_DIR/README_V51_4.md" README_V51_4.md

echo "目前版本："
cat src/utils/version.ts

npm install
npm run build

git add src/pages/PaymentPage.tsx \
        src/pages/FinanceConfirmPage.tsx \
        src/utils/sort.ts \
        src/utils/version.ts \
        README_V51_4.md

if git diff --cached --quiet; then
  echo "檔案內容已是 V51.4，建立空提交以觸發 Vercel。"
  git commit --allow-empty -m "Trigger ARC V51.4 deployment"
else
  git commit -m "ARC V51.4 sort payment and finance details"
fi

git push origin main

echo "部署提交完成。系統版本應顯示 ARC V13.51.4。"
