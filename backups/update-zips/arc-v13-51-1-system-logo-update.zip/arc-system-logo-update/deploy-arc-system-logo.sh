#!/usr/bin/env bash
set -euo pipefail
PROJECT_DIR="${1:-/workspaces/for-e-arcv2}"
UPDATE_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$PROJECT_DIR"

echo "[1/7] 更新網站圖示與系統 LOGO..."
mkdir -p public src/components src/pages
cp -f "$UPDATE_DIR/public/arc-logo.png" public/arc-logo.png
cp -f "$UPDATE_DIR/public/arc-icon-192.png" public/arc-icon-192.png
cp -f "$UPDATE_DIR/public/apple-touch-icon.png" public/apple-touch-icon.png
cp -f "$UPDATE_DIR/public/favicon-32.png" public/favicon-32.png
cp -f "$UPDATE_DIR/public/favicon-16.png" public/favicon-16.png
cp -f "$UPDATE_DIR/public/favicon.ico" public/favicon.ico
cp -f "$UPDATE_DIR/index.html" index.html
cp -f "$UPDATE_DIR/src/components/AppShell.tsx" src/components/AppShell.tsx
cp -f "$UPDATE_DIR/src/pages/LoginPage.tsx" src/pages/LoginPage.tsx

# append CSS override only once
if ! grep -q "ARC V13.51.2 system logo update" src/styles.css; then
  cat "$UPDATE_DIR/src/styles-logo-update.css" >> src/styles.css
fi

echo "[2/7] 確認檔案..."
test -f public/arc-logo.png
grep -q 'src="/arc-logo.png"' src/components/AppShell.tsx
grep -q 'src="/arc-logo.png"' src/pages/LoginPage.tsx

echo "[3/7] 安裝套件..."
npm install

echo "[4/7] 正式編譯..."
npm run build

echo "[5/7] Git 狀態..."
git status --short

echo "[6/7] 建立提交..."
git add index.html public/arc-logo.png public/arc-icon-192.png public/apple-touch-icon.png public/favicon-32.png public/favicon-16.png public/favicon.ico src/components/AppShell.tsx src/pages/LoginPage.tsx src/styles.css
if git diff --cached --quiet; then
  git commit --allow-empty -m "Trigger ARC logo redeploy"
else
  git commit -m "Update ARC favicon and system logo"
fi

echo "[7/7] 推送 main..."
git push origin main

echo "完成：網站分頁圖示、側邊欄 LOGO、登入頁 LOGO 已更新。"
