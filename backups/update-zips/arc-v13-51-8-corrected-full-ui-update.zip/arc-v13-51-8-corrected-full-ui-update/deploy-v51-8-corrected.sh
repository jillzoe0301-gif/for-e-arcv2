#!/usr/bin/env bash
set -euo pipefail

PROJECT_DIR="${1:-/workspaces/for-e-arcv2}"
PATCH_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

cd "$PROJECT_DIR"

echo "[1/7] 確認專案與分支"
git status --short
echo "branch: $(git branch --show-current)"

if [ "$(git branch --show-current)" != "main" ]; then
  echo "錯誤：目前不是 main 分支，停止部署。"
  exit 1
fi

echo "[2/7] 先同步 GitHub main"
git fetch origin main
git pull --rebase origin main

echo "[3/7] 覆蓋 V13.51.8 修正版核心檔案"
cp -f "$PATCH_DIR/src/pages/FinanceConfirmPage.tsx" "$PROJECT_DIR/src/pages/FinanceConfirmPage.tsx"
cp -f "$PATCH_DIR/src/pages/PaymentPage.tsx" "$PROJECT_DIR/src/pages/PaymentPage.tsx"
cp -f "$PATCH_DIR/src/pages/CaseRegistrationPage.tsx" "$PROJECT_DIR/src/pages/CaseRegistrationPage.tsx"
cp -f "$PATCH_DIR/src/styles.css" "$PROJECT_DIR/src/styles.css"
cp -f "$PATCH_DIR/src/utils/version.ts" "$PROJECT_DIR/src/utils/version.ts"
cp -f "$PATCH_DIR/README_V51_8_CORRECTED.md" "$PROJECT_DIR/README_V51_8_CORRECTED.md"

echo "[4/7] 驗證檔案真的已覆蓋"
grep -q "finance-confirm-batch-card" src/pages/FinanceConfirmPage.tsx
grep -q "brokerToneClass" src/pages/PaymentPage.tsx
grep -q "single-case-form" src/pages/CaseRegistrationPage.tsx
grep -q "ARC V13.51.8" src/utils/version.ts

echo "核心檔案驗證 OK"

echo "[5/7] 正式編譯"
if [ ! -d node_modules ]; then
  npm install
fi
npm run build

echo "[6/7] 提交 Git"
git add \
  src/pages/FinanceConfirmPage.tsx \
  src/pages/PaymentPage.tsx \
  src/pages/CaseRegistrationPage.tsx \
  src/styles.css \
  src/utils/version.ts \
  README_V51_8_CORRECTED.md

if git diff --cached --quiet; then
  echo "沒有新的程式差異，建立空提交觸發 Vercel。"
  git commit --allow-empty -m "Redeploy ARC V13.51.8 corrected UI"
else
  git commit -m "ARC V13.51.8 corrected finance payment registration UI"
fi

echo "[7/7] 推送 main"
git push origin main

echo
echo "============================================="
echo "ARC V13.51.8 修正版已推送。"
echo "請至 Vercel Deployments 等待最新 main 部署完成。"
echo "============================================="
