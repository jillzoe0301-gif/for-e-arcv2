#!/usr/bin/env bash
set -euo pipefail

TARGET="${1:-/workspaces/for-e-arcv2}"
HERE="$(cd "$(dirname "$0")" && pwd)"

echo "== ARC V13.51.8 財務對帳/居留證繳費/案件登記介面更新 =="
echo "專案：$TARGET"

if [ ! -d "$TARGET/src" ]; then
  echo "找不到專案 src：$TARGET/src"
  exit 1
fi

cp -f "$HERE/src/pages/FinanceSearchPage.tsx" "$TARGET/src/pages/FinanceSearchPage.tsx"
cp -f "$HERE/src/pages/FinanceConfirmPage.tsx" "$TARGET/src/pages/FinanceConfirmPage.tsx"
cp -f "$HERE/src/pages/PaymentPage.tsx" "$TARGET/src/pages/PaymentPage.tsx"
cp -f "$HERE/src/pages/CaseRegistrationPage.tsx" "$TARGET/src/pages/CaseRegistrationPage.tsx"
cp -f "$HERE/src/styles.css" "$TARGET/src/styles.css"
cp -f "$HERE/src/utils/version.ts" "$TARGET/src/utils/version.ts"
cp -f "$HERE/README_V51_8.md" "$TARGET/README_V51_8.md"

cd "$TARGET"

echo "目前版本："
cat src/utils/version.ts

echo "執行編譯檢查..."
if [ -d node_modules ]; then
  npm run build
else
  npm install
  npm run build
fi

echo "提交 Git..."
git add src/pages/FinanceSearchPage.tsx src/pages/FinanceConfirmPage.tsx src/pages/PaymentPage.tsx src/pages/CaseRegistrationPage.tsx src/styles.css src/utils/version.ts README_V51_8.md
if git diff --cached --quiet; then
  echo "沒有新的檔案差異，建立空提交觸發部署。"
  git commit --allow-empty -m "ARC V13.51.8 finance confirm payment and registration UI"
else
  git commit -m "ARC V13.51.8 finance confirm payment and registration UI"
fi

echo "同步遠端最新內容..."
if ! git pull --rebase origin main; then
  echo "git pull --rebase 發生衝突，請先處理衝突後再重新執行 git push origin main。"
  exit 1
fi

git push origin main

echo "完成：已推送 main，請等待 Vercel 自動部署。"
echo "部署後版本：ARC V13.51.8"
