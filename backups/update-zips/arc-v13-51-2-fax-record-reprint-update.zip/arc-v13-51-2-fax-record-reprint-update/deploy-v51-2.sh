#!/usr/bin/env bash
set -euo pipefail

PROJECT_DIR="${1:-/workspaces/for-e-arcv2}"
UPDATE_DIR="$(cd "$(dirname "$0")" && pwd)"

cd "$PROJECT_DIR"

echo "[1/6] 覆蓋 ARC V13.51.2 更新檔..."
cp -f "$UPDATE_DIR/src/pages/FaxPickupPage.tsx" src/pages/FaxPickupPage.tsx
cp -f "$UPDATE_DIR/src/utils/version.ts" src/utils/version.ts
cp -f "$UPDATE_DIR/README_V51_2.md" README_V51_2.md

echo "[2/6] 確認版本與功能..."
grep -q "ARC V13.51.2" src/utils/version.ts
grep -q "補印傳真領件單" src/pages/FaxPickupPage.tsx

echo "[3/6] 安裝套件..."
npm install

echo "[4/6] 正式編譯..."
npm run build

echo "[5/6] 建立 Git 提交..."
git add src/pages/FaxPickupPage.tsx src/utils/version.ts README_V51_2.md
if git diff --cached --quiet; then
  git commit --allow-empty -m "Trigger ARC V13.51.2 redeploy"
else
  git commit -m "ARC V13.51.2 add fax pickup record reprint"
fi

echo "[6/6] 推送 main..."
git push origin main

echo "完成：請到 Vercel Deployments 確認最新部署。"
echo "系統版本應顯示：ARC V13.51.2"
