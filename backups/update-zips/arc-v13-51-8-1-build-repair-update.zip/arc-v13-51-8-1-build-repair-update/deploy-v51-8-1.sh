#!/usr/bin/env bash
set -euo pipefail

PROJECT_DIR="${1:-/workspaces/for-e-arcv2}"
PATCH_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

cd "$PROJECT_DIR"

echo "============================================="
echo "ARC V13.51.8.1 修復部署"
echo "============================================="

echo "[1/9] 檢查 main 分支"
BRANCH="$(git branch --show-current)"
echo "branch: $BRANCH"
if [ "$BRANCH" != "main" ]; then
  echo "錯誤：目前不是 main 分支。"
  exit 1
fi

echo "[2/9] 保留本機未提交變更檢查"
if ! git diff --quiet || ! git diff --cached --quiet; then
  echo "目前有未提交的程式變更，為避免覆蓋，停止部署。"
  echo "請先執行 git status 確認。"
  exit 1
fi

echo "[3/9] 同步 GitHub main"
git fetch origin main
git pull --rebase origin main

echo "[4/9] 覆蓋 V13.51.8.1 核心檔案"
cp -f "$PATCH_DIR/src/pages/FinanceConfirmPage.tsx" "$PROJECT_DIR/src/pages/FinanceConfirmPage.tsx"
cp -f "$PATCH_DIR/src/pages/PaymentPage.tsx" "$PROJECT_DIR/src/pages/PaymentPage.tsx"
cp -f "$PATCH_DIR/src/pages/CaseRegistrationPage.tsx" "$PROJECT_DIR/src/pages/CaseRegistrationPage.tsx"
cp -f "$PATCH_DIR/src/styles.css" "$PROJECT_DIR/src/styles.css"
cp -f "$PATCH_DIR/src/utils/sort.ts" "$PROJECT_DIR/src/utils/sort.ts"
cp -f "$PATCH_DIR/src/utils/version.ts" "$PROJECT_DIR/src/utils/version.ts"
cp -f "$PATCH_DIR/README_V51_8_1.md" "$PROJECT_DIR/README_V51_8_1.md"

echo "[5/9] 驗證更新內容"
grep -q "finance-confirm-batch-card" src/pages/FinanceConfirmPage.tsx
grep -q "brokerToneClass" src/pages/PaymentPage.tsx
grep -q "single-case-form" src/pages/CaseRegistrationPage.tsx
grep -q "sortCasesByApplicationDateAndGroup" src/utils/sort.ts
grep -q "ARC V13.51.8.1" src/utils/version.ts
echo "核心檔案驗證 OK"

echo "[6/9] 清除舊編譯與相依套件"
rm -rf dist node_modules
npm cache verify || true

echo "[7/9] 依 package-lock 重新安裝"
npm ci

echo "Node: $(node -v)"
echo "npm:  $(npm -v)"
echo "Vite: $(node -p \"require('./node_modules/vite/package.json').version\")"

echo "[8/9] 正式編譯"
npm run build

echo "[9/9] Git commit / push"
git add \
  src/pages/FinanceConfirmPage.tsx \
  src/pages/PaymentPage.tsx \
  src/pages/CaseRegistrationPage.tsx \
  src/styles.css \
  src/utils/sort.ts \
  src/utils/version.ts \
  README_V51_8_1.md

if git diff --cached --quiet; then
  git commit --allow-empty -m "Redeploy ARC V13.51.8.1 build repair"
else
  git commit -m "ARC V13.51.8.1 repair build and UI update"
fi

git push origin main

echo
echo "============================================="
echo "完成：ARC V13.51.8.1 已推送至 main"
echo "請等待 Vercel 最新 Deployment 完成。"
echo "============================================="
