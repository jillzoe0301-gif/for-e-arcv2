# ARC 網站圖示更新檔

內容：
- `public/favicon.ico`
- `public/favicon-16.png`
- `public/favicon-32.png`
- `public/apple-touch-icon.png`
- `public/arc-icon-192.png`
- `public/arc-logo.png`
- 已加入 favicon 設定的 `index.html`
- Codespaces bash 自動部署程式 `deploy-arc-favicon.sh`
