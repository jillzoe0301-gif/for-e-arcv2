#!/usr/bin/env bash
set -euo pipefail

PROJECT_DIR="${1:-/workspaces/for-e-arcv2}"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

cd "$PROJECT_DIR"

echo "[1/6] 覆蓋 ARC 網站圖示與 index.html"
cp -f "$SCRIPT_DIR/index.html" ./index.html
cp -f "$SCRIPT_DIR/public/arc-logo.png" ./public/arc-logo.png
cp -f "$SCRIPT_DIR/public/arc-icon-192.png" ./public/arc-icon-192.png
cp -f "$SCRIPT_DIR/public/apple-touch-icon.png" ./public/apple-touch-icon.png
cp -f "$SCRIPT_DIR/public/favicon-32.png" ./public/favicon-32.png
cp -f "$SCRIPT_DIR/public/favicon-16.png" ./public/favicon-16.png
cp -f "$SCRIPT_DIR/public/favicon.ico" ./public/favicon.ico

echo "[2/6] 確認 favicon 設定"
grep -n "favicon\|apple-touch-icon\|theme-color" index.html

echo "[3/6] 安裝相依套件"
npm install

echo "[4/6] 正式編譯"
npm run build

echo "[5/6] 提交 Git"
git add index.html public/arc-logo.png public/arc-icon-192.png public/apple-touch-icon.png public/favicon-32.png public/favicon-16.png public/favicon.ico
if git diff --cached --quiet; then
  echo "程式檔沒有新增變更，建立空提交觸發 Vercel。"
  git commit --allow-empty -m "Refresh ARC favicon deployment"
else
  git commit -m "Update ARC website favicon"
fi

echo "[6/6] 推送 main"
git push origin main

echo
echo "部署提交已推送。請至 Vercel Deployments 等待完成後，關閉舊分頁再重新開啟網站。"
