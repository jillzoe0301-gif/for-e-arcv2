#!/usr/bin/env bash
set -euo pipefail

TARGET="${1:-/workspaces/for-e-arcv2}"
HERE="$(cd "$(dirname "$0")" && pwd)"

echo "== ARC V13.51.6 上方文字導覽更新 =="
echo "專案：$TARGET"

if [ ! -d "$TARGET/src" ]; then
  echo "找不到專案 src：$TARGET/src"
  exit 1
fi

cp -f "$HERE/src/App.tsx" "$TARGET/src/App.tsx"
cp -f "$HERE/src/styles.css" "$TARGET/src/styles.css"
cp -f "$HERE/src/components/AppShell.tsx" "$TARGET/src/components/AppShell.tsx"
cp -f "$HERE/src/pages/AgencyContactsPage.tsx" "$TARGET/src/pages/AgencyContactsPage.tsx"
cp -f "$HERE/src/pages/SettingsPage.tsx" "$TARGET/src/pages/SettingsPage.tsx"
cp -f "$HERE/src/utils/permissions.ts" "$TARGET/src/utils/permissions.ts"
cp -f "$HERE/src/utils/version.ts" "$TARGET/src/utils/version.ts"
cp -f "$HERE/README_V51_6.md" "$TARGET/README_V51_6.md"

cd "$TARGET"

echo "目前版本："
cat src/utils/version.ts

echo "執行編譯檢查..."
if [ -d node_modules ]; then
  npm run build
else
  npm install
  npm run build
fi

echo "提交 Git..."
git add src/App.tsx src/styles.css src/components/AppShell.tsx src/pages/AgencyContactsPage.tsx src/pages/SettingsPage.tsx src/utils/permissions.ts src/utils/version.ts README_V51_6.md
if git diff --cached --quiet; then
  echo "沒有新的檔案差異，建立空提交觸發部署。"
  git commit --allow-empty -m "ARC V13.51.6 top navigation full width"
else
  git commit -m "ARC V13.51.6 top navigation full width"
fi

git push origin main

echo "完成：已推送 main，請等待 Vercel 自動部署。"
echo "部署後版本：ARC V13.51.6"
